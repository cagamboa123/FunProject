package com.example.cagamboa.ledstriptest;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;

import com.google.android.things.contrib.driver.button.Button;
import com.google.android.things.contrib.driver.button.ButtonInputDriver;
import com.google.android.things.contrib.driver.pwmspeaker.Speaker;
import com.google.android.things.pio.Gpio;
import java.io.IOException;

import com.google.android.things.contrib.driver.apa102.Apa102;
import com.google.android.things.contrib.driver.ht16k33.AlphanumericDisplay;
import com.google.android.things.contrib.driver.ht16k33.Ht16k33;
import com.google.android.things.contrib.driver.rainbowhat.RainbowHat;
import com.google.android.things.contrib.driver.bmx280.Bmx280;
import com.google.android.things.pio.I2cDevice;
import com.google.android.things.userdriver.pio.I2cBusDriver;

public class MainActivity extends Activity {

    private static final String BUTTON_PIN_NAME = "GPIO6_IO14";

    private static final String TAG = "HomeActivity";
    private static final String BUTTON_PIN_NAMEA = "GPIO6_IO14";
    private static final String BUTTON_PIN_NAMEB = "GPIO6_IO15";
    private static final String BUTTON_PIN_NAMEC = "GPIO2_IO07"; //note different GPIO!

    // GPIO connection to button input
    private Gpio mButtonGpio;
    private Apa102 ledstrip;
    private Speaker buzzer;
    private static final String APA102_RGB_7_LED_SLAVE = "SPI3.1";
    Apa102 mApa102;
    private ButtonInputDriver mButtonInputDriverA;
    private ButtonInputDriver mButtonInputDriverB;
    private ButtonInputDriver mButtonInputDriverC;
    private Gpio mLedGpio;
    Gpio led;
    Gpio gled;
    Gpio bled;
    int count;
    float data;
    Bmx280 temperature;


    void pause(int time)
    {
        try
        {
            Thread.sleep(time);
        }
        catch(InterruptedException ex)
        {
            Thread.currentThread().interrupt();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            temperature = new Bmx280("I2C1");
            temperature.setTemperatureOversampling(Bmx280.OVERSAMPLING_1X);
            temperature.setPressureOversampling(Bmx280.OVERSAMPLING_1X);
            temperature.setMode(Bmx280.MODE_NORMAL);
            Log.d(TAG, "Initialized BME280");

            mButtonInputDriverA = new ButtonInputDriver(
                    BUTTON_PIN_NAMEA,
                    Button.LogicState.PRESSED_WHEN_LOW,
                    KeyEvent.KEYCODE_A);
            // Register with the framework
            mButtonInputDriverA.register();

            mButtonInputDriverB = new ButtonInputDriver(
                    BUTTON_PIN_NAMEB,
                    Button.LogicState.PRESSED_WHEN_LOW,
                    KeyEvent.KEYCODE_B);
            // Register with the framework
            mButtonInputDriverB.register();

            mButtonInputDriverC = new ButtonInputDriver(
                    BUTTON_PIN_NAMEC,
                    Button.LogicState.PRESSED_WHEN_LOW,
                    KeyEvent.KEYCODE_C);
            // Register with the framework
            mButtonInputDriverC.register();

        } catch (IOException e) {
            Log.w(TAG, "Error opening GPIO 1", e);
        }


        try {

            Log.d(TAG, "write to the seven segment " );
            AlphanumericDisplay segment = RainbowHat.openDisplay();
            segment.setBrightness(Ht16k33.HT16K33_BRIGHTNESS_MAX);
            for(int i=8888; i < 8895; i++)
            {
                String stt = String.valueOf(i);
                segment.display(stt);
                segment.setEnabled(true);
                pause(500);
            }
            segment.display("****");
            segment.close();
            // Light up the LEDs.
            Gpio led = RainbowHat.openLedRed();
            Gpio gled = RainbowHat.openLedGreen();
            Gpio bled = RainbowHat.openLedBlue();
            led.close();
            gled.close();
            bled.close();

            //turn red LED off and on
            Log.w(TAG, "red");
            led = RainbowHat.openLedRed();
            led.setValue(false);
            pause(500);
            led.setValue(true);
            led.close();

            //turn red green off and on
            gled = RainbowHat.openLedGreen();
            Log.w(TAG, "Green");
            gled.setValue(false);
            pause(500);
            gled.setValue(true);
            pause(500);
            // Close the device when done.
            gled.close();

            //turn blue LED off and on
            led = RainbowHat.openLedBlue();
            Log.w(TAG, "Blue");
            bled.setValue(false);
            pause(500);
            bled.setValue(true);
            pause(500);
            // Close the device when done.
            bled.close();

            //write different colors to the LED strip
            ledstrip = RainbowHat.openLedStrip();
            ledstrip.setBrightness(18);
            ledstrip.setDirection(Apa102.Direction.NORMAL);
            int[] rainbow = new int[RainbowHat.LEDSTRIP_LENGTH];
            for (int i = 0; i < rainbow.length; i++) {
                rainbow[i] = Color.HSVToColor(255, new float[]{i * 360.f / rainbow.length, 1.0f, 1.0f});
                ledstrip.write(rainbow);
                pause(500);
            }
            // Close the device when done.
            //ledstrip.close();
        } catch (IOException e) {
            Log.w(TAG, "Error opening GPIO 1", e);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        // Unregister the driver and close
        if (mButtonInputDriverA != null) {
            mButtonInputDriverA.unregister();
            try {
                mButtonInputDriverA.close();
            } catch (IOException e) {
                Log.e(TAG, "Error closing Button driver", e);
            }
        }

        // Close the LED.
        if (mLedGpio != null) {
            try {
                mLedGpio.close();
            } catch (IOException e) {
                Log.e(TAG, "Error closing GPIO", e);
            }
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_A) {
            Log.i(TAG, "A Button down");
            count = 1;
            return true;
        }

        else if (keyCode == KeyEvent.KEYCODE_B) {
            Log.i(TAG, "B Button down");
            count = count + 1;
            return true;
        }

        else if (keyCode == KeyEvent.KEYCODE_C) {
            Log.i(TAG, "C Button down");
            count = 0;
            return true;
        }

        return super.onKeyDown(keyCode, event);
        }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {

        if(count == 2){
            try{

                if (temperature != null) {
                    data = temperature.readTemperature();
                    Log.d(TAG, String.valueOf(data));
                }
                else if(temperature == null) {
                    data = 0;
                }
            Log.d(TAG, String.valueOf(data));
            Log.i(TAG, "sequence met");
            AlphanumericDisplay segment = RainbowHat.openDisplay();
            segment.display("T=" + Math.round(data));
            segment.close();
            count = 0;
            }catch(IOException e){
                Log.w(TAG, "can't write to 7 segments", e);
            }}
        if (keyCode == KeyEvent.KEYCODE_A) {
            try {
                //mButtonInputDriverA.close();
                led = RainbowHat.openLedRed();
                Log.i(TAG, "A Button up");
                led.setValue(false);
                pause(500);
                led.setValue(true);
                led.close();

                //turn the LED strip to all red
                int[] rainbow = new int[RainbowHat.LEDSTRIP_LENGTH];
                for (int i = 0; i < rainbow.length; i++) {
                    rainbow[i] = Color.HSVToColor(255, new float[]{i/7 * 360.f / 4, 1.0f, 1.0f});
                    ledstrip.write(rainbow);
                    pause(500);
                }
                return true;
            } catch (IOException e) {
                Log.w(TAG, "can't blink LED", e);
            }}

        else if (keyCode == KeyEvent.KEYCODE_B) {
            // Turn on the LED when the button is pushed
            try {
                //mButtonInputDriverB.close();
                gled = RainbowHat.openLedGreen();
                Log.i(TAG, "B Button up");
                gled.setValue(false);
                pause(500);
                gled.setValue(true);
                gled.close();

                //turn the LED strip to all red
                int[] rainbow = new int[RainbowHat.LEDSTRIP_LENGTH];
                for (int i = 0; i < rainbow.length; i++) {
                    rainbow[i] = Color.HSVToColor(255, new float[]{1 * 360.f / 4, 1.0f, 1.0f});
                    ledstrip.write(rainbow);
                    pause(500);
                }
                return true;
            } catch (IOException e) {
                Log.w(TAG, "can't blink LED", e);
            }}

        else if (keyCode == KeyEvent.KEYCODE_C) {
            // Turn on the LED when the button is pushed
            try {
                //mButtonInputDriverC.close();
                bled = RainbowHat.openLedBlue();
                Log.i(TAG, "C Button up");
                bled.setValue(false);
                pause(500);
                bled.setValue(true);
                bled.close();

                //turn the LED strip to all red
                int[] rainbow = new int[RainbowHat.LEDSTRIP_LENGTH];
                for (int i = 0; i < rainbow.length; i++) {
                    rainbow[i] = Color.HSVToColor(255, new float[]{2 * 360.f / 5, 1.0f, 1.0f});
                    ledstrip.write(rainbow);
                    pause(500);
                }
                return true;
            } catch (IOException e) {
                Log.w(TAG, "can't blink LED", e);
            }}
            return super.onKeyUp(keyCode, event);
    }

    /**
     * Update the value of the LED output.
     */
    private void setLedValue(boolean value) {
        try {
            mLedGpio.setValue(value);
        } catch (IOException e) {
            Log.e(TAG, "Error updating GPIO value", e);
        }
    }
}